<footer class="text-center mt-5">
    <div class="footer clearfix mb-0 text-muted">
        <div>
            <p class="m-0">2022 &copy; Library</p>
        </div>
        <div class="m-0">
            <p>Crafted with <span class="text-danger"><i class="bi bi-heart"></i></span> by My team</p>
        </div>
    </div>
</footer>