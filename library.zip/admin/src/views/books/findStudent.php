<div class="container my-5 w-50">
    <h3 class="text-center my-5">Tìm sinh viên theo mã số sinh viên</h3>
    <form action="index.php?controller=book&action=borrow" method="post">
        <div class="my-2">
            <label class="form-label">Mã số sinh viên</label>
            <input class="form-control" type="text" name="mssv" id="mssv" placeholder="Nhập mã số sinh viên">
        </div>
        <button class="btn btn-primary">Tìm kiếm sinh viên</button>
    </form>
</div>