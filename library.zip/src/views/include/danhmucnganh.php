<!-- End Counter -->
<div class="container">
    <div class="row">
        <div class="col-12">
            <div class="style_title d-flex align-items-center"
                style="background-color:#f2f2f2; padding: 15px; border-radius: 7px;">
                <i class="fa fa-list" style="font-size:25px;color:#49b2df;"></i>
                <b style="color:black; padding-left: 10px;"> Truy cập theo ngành đào tạo </b>
            </div>
        </div>
    </div>
    <div class="menu my-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3" style="text-align:center">
                    <a class="category-book" href="index.php?controller=book&action=filtercategory1"> <i class="fa fa-microchip fa-4x"
                           ></i><br>Công nghệ thông tin</a>
                </div>
                <div class="col-lg-3" style="text-align:center">
                    <a class="category-book" href="index.php?controller=book&action=filtercategory2"><i
                            class="fa-solid fa-square-poll-vertical fa-4x"></i><br>Kinh tế</a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.menu {
    margin-top: 10px;
}

.menu1 {
    margin-top: 30px;
}
</style>