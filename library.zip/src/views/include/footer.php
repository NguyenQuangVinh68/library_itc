<!-- Start footer -->
<footer class="py-5 mt-4" style="background-color:#0c4470;">
    <div class="container-fluid p-0">
        <div class="text-center text-white">
            <p class="mb-0 text-capitalize">thư viện cao đẳng công nghệ thông tin tp.HCM - ITC</p>
            <p class="mb-0"><a href="" class="text-white">info@itc.edu.vn</a></p>
            <p class="mb-0">&copy; Copyright by MyTeam</p>
        </div>
    </div>
    <div class="container-fluid text-center background-footer overflow-hidden">

        <img class="w-100 background1" src="https://vn.got-it.ai/blog/wp-content/themes/gotitblog/assets/images/footer-top.svg" alt="">

    </div>
</footer>

<style>
    .background-footer {
        display: flex;
    }

    /* .background-footer .background1 {
        position: relative;
        top: 100%;
        animation: animateBg1 linear 10s forwards;
    } */

    /* @keyframes animateBg1 {
        from {
            left: -100%;
        }
        to {
            left: 100%;
        }
    } */
</style>
