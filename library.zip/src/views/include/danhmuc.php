<!-- End Counter -->

<!-- <div class="container mb-3">
    <div class="row">
        <div class="col-12 mt-3">
            <div class="style_title d-flex align-items-center" style="background-color:#f2f2f2; padding: 15px; border-radius: 7px;">
                <i class="fa fa-list" style="font-size:25px;color:#49b2df;"></i>
                <b style="color:black; padding-left: 10px;"> Truy cập nhanh các danh mục </b>
            </div>
        </div>
    </div>
    <div class="menu my-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-3" style="text-align:center">
                    <a class="category-book" href="index.php?controller=book&action=filtercategory3">
                        <i class="fa fa-book fa-4x"></i><br>
                        Sách Tham Khảo</a>
                </div>
                <div class="col-lg-3" style="text-align:center">

                    <a class="category-book" href="index.php?controller=book&action=filtercategory4"><i class="fa fa-leanpub fa-4x"></i><br>Đồ án TN ĐH-CĐ</a>

                </div>
                <div class="col-lg-3" style="text-align:center">
                    <a class="category-book" href="index.php?controller=book&action=filtercategory5"><i class="fa fa-pencil-square-o fa-4x"></i><br>Sách Giáo Trình</a>

                </div>
                <div class="col-lg-3" style="text-align:center">
                    <a class="category-book" href="index.php?controller=book&action=filtercategory6"><i class="fa fa-newspaper-o fa-4x"></i><br>Báo Tạp Chí</a>

                </div>
            </div>
        </div>
    </div>
</div> -->

<style>
    /* .menu {
    margin-top: 10px;
}

.menu1 {
    margin-top: 30px;
}

.category-book {
    cursor: pointer;
}

.category-book:hover {
    text-decoration: underline;
}

.category-book i {
    color: #49b2df;
}

.category-book:hover i, .category-book:hover {
    color: #0c4470;
} */
</style>